#init file can be empty
